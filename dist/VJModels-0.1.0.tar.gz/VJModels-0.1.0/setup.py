from setuptools import setup, find_packages

setup(
    name="VJModels",
    version="0.1.0",
    description="My own models for machine learning.",
    author="Vanderval Borges de Souza Junor",
    author_email="vander31bs@gmail.com",
    packages=find_packages(include=["VJModels", "VJModels.*"]),  # Find packages recursively
)